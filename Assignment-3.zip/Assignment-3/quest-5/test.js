var p1={
    firstName: "Lionel",
    lastName: "Messi"
};

console.log(p1.middleName);

p1.middleName= "Andres";

console.log(p1.middleName);