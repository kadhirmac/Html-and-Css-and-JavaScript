var p1={
    firstName: "Lionel",
    lastName: "Messi"
};

console.log(p1.firstName+" "+p1.lastName);

p1.lastName="Ronaldo";

console.log(p1.firstName+" "+p1.lastName);