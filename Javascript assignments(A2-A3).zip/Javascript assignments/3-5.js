var p1={
    firstName: "James",
    lastName: "Bond"
};

console.log(p1.middleName);

p1.middleName= "007 Boom";

console.log(p1.middleName);