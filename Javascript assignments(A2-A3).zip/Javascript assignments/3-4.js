var p1={
    firstName: "James",
    lastName: "Bond"
};

console.log(p1.firstName+" "+p1.lastName);

p1.lastName="007";

console.log(p1.firstName+" "+p1.lastName);