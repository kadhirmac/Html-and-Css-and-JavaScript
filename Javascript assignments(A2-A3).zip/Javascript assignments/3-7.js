var obj= { "firstName": "James", "lastName": "Bond" };

var p1= JSON.parse(JSON.stringify(obj));

console.log(p1.firstName+" "+p1.lastName);

p1.lastName="Kadhir";

console.log(p1.firstName+" "+p1.lastName);

console.log(p1.middleName);

p1.middleName= "Mac";

console.log(p1.middleName);