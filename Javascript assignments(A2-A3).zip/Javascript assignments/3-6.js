var obj= "var p1={ firstName: 'James', lastName: 'Bond' };";

eval(obj);

console.log(p1.firstName+" "+p1.lastName);

p1.lastName="kadhir";

console.log(p1.firstName+" "+p1.lastName);

console.log(p1.middleName);

p1.middleName= "Mac";

console.log(p1.middleName);