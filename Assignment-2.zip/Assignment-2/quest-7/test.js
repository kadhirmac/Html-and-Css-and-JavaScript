console.log((function repeat(x) {return repeat+'('+x+')'; })(25));
document.write((function repeat(x) {return repeat+'('+x+')'; })(25));