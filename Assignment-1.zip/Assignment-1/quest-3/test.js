function find(){
    var n= document.getElementById("n").value;
    if(n%2)
        alert(n+" is an odd number");
    else
        alert(n+" is an even number");
}