   // JavaScript code for concat() method
   function func() {
    var num1 = ["a","b","c"],
        num2 = [1,2,3],
        num3 = [4,5,6];
    document.write(num1.concat(num2, num3));
}
func();